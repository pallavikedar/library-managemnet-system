
from django import forms
from authapp.models import User
from django.contrib.auth.forms import UserCreationForm

gender_choices=(
    ('Male','Male'),
    ('Female','Female'),
    ("Other","Other")
    )

class UserRegistration(UserCreationForm):
    gender = forms.ChoiceField(label='Gender',choices=gender_choices, widget=forms.Select())
    class Meta:
        model = User
        fields = ('name', "registered_emailed", "contact_number", "address", "gender", "password1", "password2")

class LoginForm(forms.Form):
    username = forms.CharField(
        widget= forms.TextInput(
            attrs={
                "class": "form-control",
                 "placeholder":"ex.xyz@gmail.com",
            }
        )
    )
    password = forms.CharField(
        widget=forms.PasswordInput(
            attrs={
                "class": "form-control"
            }
        )
    )