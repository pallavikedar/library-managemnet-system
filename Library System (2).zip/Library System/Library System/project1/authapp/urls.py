from django.urls import path
from authapp.views import signUp,LoginView

urlpatterns = [
    path('sign/', signUp, name="signup_url"),
    path('login/',LoginView,name="login_url"),
]
