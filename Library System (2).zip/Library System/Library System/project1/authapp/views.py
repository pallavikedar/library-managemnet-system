from django.shortcuts import render
from .forms import UserRegistration,LoginForm
from django.contrib.auth import authenticate, login, logout

# Create your views here.

def signUp(request):
    form = UserRegistration()
    template_name = "authapp/signup.html"
    if request.method == "POST":
        form = UserRegistration(request.POST)
        if form.is_valid():
             form.save()
    context = {"form": form}
    return render(request, template_name, context)

def LoginView(request):
    form = LoginForm(request.POST or None)
    template_name = "authapp/login.html"
    context = {"form": form}
    if request.method == 'POST':
        un = request.POST.get('un')
        pw = request.POST.get('pw')

        user = authenticate(username = un, password= pw)
        if user is not None:
            login(request, user)

    return render(request, template_name, context)
