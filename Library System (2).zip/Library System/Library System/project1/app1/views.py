from django.shortcuts import render,redirect
from .forms import LibraryForm,Library

# Create your views here.
def libView(request):
    form=LibraryForm()
    template_name = 'app1/library_form.html'
    context = {'form':form}
    if request.method == 'POST':
        form = LibraryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('show_url')

    return render(request,template_name,context)


def showView(request):
    obj = Library.objects.all()
    template_name = 'app1/show_library.html'
    context = {'obj': obj}
    return render (request,template_name,context)

def updatelibView(request,id):
    obj = Library.objects.get(l_id = id)

    form = LibraryForm(instance=obj)
    template_name = 'app1/library_form.html'
    if request.method == 'POST':
        form = LibraryForm(request.POST,instance=obj)
        if form.is_valid():
            form.save()
            return redirect('show_url')
    context = {'form': form}
    return render(request,template_name,context)

def deletelibView(request,id):
    obj = Library.objects.get(l_id=id)
    template_name = 'app1/confirmations.html'
    context={'obj': obj}
    if request.method == 'POST':
        obj.delete()
        return redirect('show_url')
    return render(request, template_name, context)






