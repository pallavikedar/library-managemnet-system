from django.urls import path
from .import views

urlpatterns = [
    path('sv/',views.libView, name='add_url'),
    path('ss/',views.showView,name='show_url'),
    path('up/<int:id>/',views.updatelibView,name='update_url'),
    path('dl/<int:id>/',views.deletelibView, name='delete_url'),

   

]